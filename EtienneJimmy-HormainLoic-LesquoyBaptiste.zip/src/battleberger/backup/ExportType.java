package battleberger.backup;

public enum ExportType {
	YML, MySQL, Serialize;
}
