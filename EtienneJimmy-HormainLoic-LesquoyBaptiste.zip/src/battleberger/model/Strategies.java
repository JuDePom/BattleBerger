package battleberger.model;

public enum Strategies {Yolo, Diagonal, StrategyWithMemory};

