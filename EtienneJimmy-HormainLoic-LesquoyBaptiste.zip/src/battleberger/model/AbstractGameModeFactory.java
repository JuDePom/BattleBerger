package battleberger.model;

public abstract class AbstractGameModeFactory {

}
