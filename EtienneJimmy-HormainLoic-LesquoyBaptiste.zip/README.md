BattleBerger
============
***The best sheep wars of the entire farming community***

BattleBerger is a tiny game developed for the course distributed architecture design of the IT master of the Université de Lorraine.

It's a battleship game, with sheep.

Compilation/démarrage
==============
pour compiler: ant build
pour lancer le logiciel: ant Main

il est aussi possible de lancer le logiciel à partir du jar: "java -jar BattleBerger.jar" il ne faudra pas oublier de bouger le dossier assets à côté du jar si vous le déplacez.

Autre
===========
Le projet comprend un rapport de conception ainsi qu'un mode d'emploi, nommées respectivement BattleBergerAfter.pdf et BattleBergerModeEmploi.pdf


